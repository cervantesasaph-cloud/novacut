from pathlib import Path
import lzma,struct,zlib
# Higher compression for the engine; text doesn't need BCJ preprocessing.
for name in ('ffmpeg.exe','notices.txt'):
 raw=Path(name).read_bytes();bcj=name.endswith('.exe');lc=4;lp=0;pb=0;dictionary=1<<23
 filters=([{'id':lzma.FILTER_X86}] if bcj else [])+[{'id':lzma.FILTER_LZMA1,'preset':9|lzma.PRESET_EXTREME,'dict_size':dictionary,'lc':lc,'lp':lp,'pb':pb}]
 compressed=lzma.compress(raw,format=lzma.FORMAT_RAW,filters=filters)
 properties=bytes([(pb*5+lp)*9+lc])+struct.pack('<I',dictionary)
 Path(name+'.packed').write_bytes(struct.pack('<IIB',len(raw),zlib.crc32(raw),int(bcj))+properties+compressed)
 print(name,len(raw),len(compressed),flush=True)
