NovaCut 2.1 - Smaller build with cleaner native UI

Run NovaCut.exe directly on Windows 10/11 x64. The executable contains its rendering engine. No BAT, compiler installation, Python, or downloads are needed to use it.

UI: clips on the left; preview in the middle; clip settings on the right; timeline and export controls below. Buttons use a consistent dark style with teal primary actions. Controls were checked for overlap and bounds at default, minimum, and larger window sizes.

Retained features: trim; arrange; split; duplicate; 24-step undo/redo; playhead seek; rendered 20-source-second previews inside the app; mute and 0-200% gain; grayscale/vivid/invert filters; rotation/mirror; video/audio fades; source-resolution PNG snapshots; 480p/720p/1080p/1440p/4K export with 24/30/60 FPS; speed choices; compression quality; version 1/2 project support. Preview uses Windows Media Foundation.

Size work: frontend compiled with -Os, link-time optimization, and removal of unused functions. Bundled files use LZMA compression, x86 BCJ preprocessing for executable code, and CRC32 verification. Encoder code is restricted to the 8-bit progressive YUV420 output that the app already uses. Video input decoders and editing features remain enabled. The native rendering engine still uses temporary disk space while the app runs.

Source: sources/ contains complete FFmpeg, x264, and zlib sources. lzma/ contains the public-domain LZMA decoder and branch converter from 7-Zip 24.09. nova.c is the MIT-licensed app source. build-configuration.json records exact settings and hashes. The supplied x264 source archive is reconstructed from the source tree used to build the encoder; configure-generated and compiled files are excluded.

Build for developers: MinGW-w64 GCC/binutils and make. Build x264 with --enable-static --disable-cli --disable-opencl --disable-asm --disable-avs --disable-lavf --disable-swscale --disable-interlaced --bit-depth=8 --chroma-format=420, appending -Os -ffunction-sections -fdata-sections to its CFLAGS. Build static zlib. Build FFmpeg with the configuration in build-configuration.json, adapting local directory paths. Pack ffmpeg.exe and notices.txt with pack-resources.py. Compile resources.rc with windres. Compile nova.c, lzma/LzmaDec.c, and lzma/Bra86.c using -municode -mwindows -Os -flto -ffunction-sections -static -s -Wl,--gc-sections and link comctl32/comdlg32/gdi32/shell32/ole32/uuid. Do not use -fdata-sections on this frontend: the chosen MinGW linker script otherwise stores zero-filled undo history arrays as file data.

The packed resource format: uint32 original length, uint32 CRC32 of original bytes, uint8 BCJ flag, 5 LZMA properties bytes, raw LZMA1 stream with end marker. The decoder validates size, complete stream consumption, end marker, and CRC after reversing BCJ.

Validation: export pipeline/effect tests passed on a native Linux build of the size-tuned engine; embedded decoder round trips both resources byte-for-byte and rejects a corrupted payload; the application compiles with warnings treated as errors; version 1/2 project layouts have compile-time assertions; UI geometry checks passed at minimum, default, and larger sizes. The Windows GUI itself was not executed in this environment and still needs a Windows smoke test.
