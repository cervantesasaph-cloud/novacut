#ifndef UNICODE
#define UNICODE
#endif
#define _UNICODE
#define WIN32_LEAN_AND_MEAN
#define _WIN32_WINNT 0x0601
#define WINVER 0x0601
#define COBJMACROS
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <shellapi.h>
#include <mfplay.h>
#include <objbase.h>
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <math.h>
#include "unpack.h"

#define MAXCLIPS 64
#define PATHLEN 2048
#define WM_STATUS (WM_APP+1)
#define WM_DONE (WM_APP+2)
#define WM_FRAME (WM_APP+3)
#define WM_IMPORTED (WM_APP+4)
#define WM_MEDIASET (WM_APP+5)
#define WM_MEDIAERR (WM_APP+6)
enum { ADD=101,REMOVE,UP,DOWN,APPLY,PLAY,EXPORT,SAVE,OPEN,HELP,CANCEL,INBOX,OUTBOX,MUTE,SPEED,RES,FPS,CLIPLIST,SPLIT,DUPLICATE,UNDO,REDO,EFFECT,ROTATE,FLIP,VOLUME,FADEIN,FADEOUT,QUALITY,SEEK,MARKIN,MARKOUT,PNG,STOP };
typedef struct {wchar_t path[PATHLEN];double duration,in,out;int audio,mute;} OldClip;
typedef struct {wchar_t path[PATHLEN];double duration,in,out;int audio,mute,effect,rotation,flip,gain;double fadeIn,fadeOut;} Clip;
typedef struct {Clip clips[MAXCLIPS];int count,selected;} State;
static State undoStates[24],redoStates[24];static int undoCount=0,redoCount=0;

_Static_assert(sizeof(OldClip)==4128,"version 1 layout");
_Static_assert(sizeof(Clip)==4160,"version 2 layout");
typedef struct {int type,count,selected,width,height,fps,crf;double speed;Clip clips[MAXCLIPS];wchar_t output[PATHLEN];} Job;
static HWND win,list,inbox,outbox,mute,speed,res,fps,status,video;
static IMFPMediaPlayer *mediaPlayer=NULL;static HMODULE mediaDLL=NULL;static double playhead=0;static HFONT font,titleFont;static HBRUSH bg,panel,card;
static HINSTANCE instance;static Clip clips[MAXCLIPS];static int count=0,selected=-1,busy=0;
static wchar_t work[PATHLEN],engine[PATHLEN];static HANDLE child=NULL,worker=NULL;static CRITICAL_SECTION processLock;static volatile LONG cancelled=0;static HBITMAP frame=NULL;static RECT frameRect,timelineRect;
static void pathjoin(wchar_t *dst,const wchar_t *name){swprintf(dst,PATHLEN,L"%ls\\%ls",work,name);}
static void setStatus(const wchar_t *text){wchar_t *s=_wcsdup(text);PostMessage(win,WM_STATUS,0,(LPARAM)s);}
static void error(const wchar_t *text){MessageBox(win,text,L"NovaCut",MB_OK|MB_ICONERROR);}
static int extract(int id,const wchar_t *path){
 HRSRC r=FindResource(instance,MAKEINTRESOURCE(id),RT_RCDATA);if(!r)return 0;
 HGLOBAL h=LoadResource(instance,r);DWORD packed=SizeofResource(instance,r);unsigned char *data=LockResource(h),*raw=NULL;size_t size=0;
 if(!ncUnpack(data,packed,&raw,&size))return 0;DWORD written=0;HANDLE f=CreateFile(path,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
 if(f==INVALID_HANDLE_VALUE){free(raw);return 0;}int ok=WriteFile(f,raw,(DWORD)size,&written,NULL)&&written==size;CloseHandle(f);free(raw);return ok;
}
static int run(const wchar_t *exe,const wchar_t *args,const wchar_t *log){
 wchar_t cmd[32768];swprintf(cmd,32768,L"\"%ls\" %ls",exe,args);SECURITY_ATTRIBUTES sa={sizeof(sa),NULL,TRUE};
 HANDLE f=CreateFile(log,GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE,&sa,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);if(f==INVALID_HANDLE_VALUE)return -2;
 HANDLE nul=CreateFile(L"NUL",GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,&sa,OPEN_EXISTING,0,NULL);
 STARTUPINFO si={0};PROCESS_INFORMATION pi={0};si.cb=sizeof(si);si.dwFlags=STARTF_USESTDHANDLES;si.hStdOutput=f;si.hStdError=f;si.hStdInput=nul;
 if(InterlockedCompareExchange(&cancelled,0,0)){CloseHandle(f);CloseHandle(nul);return -3;}
 BOOL ok=CreateProcess(exe,cmd,NULL,NULL,TRUE,CREATE_NO_WINDOW,NULL,work,&si,&pi);CloseHandle(f);CloseHandle(nul);if(!ok)return -2;
 EnterCriticalSection(&processLock);child=pi.hProcess;if(cancelled)TerminateProcess(child,1);LeaveCriticalSection(&processLock);
 WaitForSingleObject(pi.hProcess,INFINITE);DWORD code;GetExitCodeProcess(pi.hProcess,&code);
 EnterCriticalSection(&processLock);child=NULL;LeaveCriticalSection(&processLock);CloseHandle(pi.hProcess);CloseHandle(pi.hThread);return (int)code;
}
static char *readlog(const wchar_t *path){FILE *f=_wfopen(path,L"rb");if(!f)return NULL;fseek(f,0,SEEK_END);long n=ftell(f);if(n>1000000)n=1000000;rewind(f);char *s=calloc(n+1,1);if(s)fread(s,1,n,f);fclose(f);return s;}
static const wchar_t *basename(const wchar_t *s){const wchar_t *p=wcsrchr(s,L'\\');return p?p+1:s;}
static double length(void){double n=0;for(int i=0;i<count;i++)n+=clips[i].out-clips[i].in;return n;}
static void capture(State *s){memcpy(s->clips,clips,sizeof(clips));s->count=count;s->selected=selected;}
static void checkpoint(void){if(undoCount==24){memmove(undoStates,undoStates+1,23*sizeof(State));undoCount--;}capture(&undoStates[undoCount++]);redoCount=0;}
static void mediaStop(void){if(mediaPlayer){IMFPMediaPlayer_Shutdown(mediaPlayer);IMFPMediaPlayer_Release(mediaPlayer);mediaPlayer=NULL;}if(video)ShowWindow(video,SW_HIDE);}
static const GUID callbackGuid={0x766c8ffb,0x5fdb,0x4fea,{0xa2,0x8d,0xb9,0x12,0x99,0x6f,0x51,0xbd}};
static HRESULT STDMETHODCALLTYPE cbQuery(IMFPMediaPlayerCallback *self,REFIID iid,void **out){if(!out)return E_POINTER;if(IsEqualIID(iid,&IID_IUnknown)||IsEqualIID(iid,&callbackGuid)){*out=self;return S_OK;}*out=NULL;return E_NOINTERFACE;}
static ULONG STDMETHODCALLTYPE cbAdd(IMFPMediaPlayerCallback *self){(void)self;return 2;}
static ULONG STDMETHODCALLTYPE cbRelease(IMFPMediaPlayerCallback *self){(void)self;return 1;}
static void STDMETHODCALLTYPE cbEvent(IMFPMediaPlayerCallback *self,MFP_EVENT_HEADER *e){(void)self;if(e->pMediaPlayer!=mediaPlayer)return;if(FAILED(e->hrEvent))PostMessage(win,WM_MEDIAERR,(WPARAM)e->hrEvent,0);else if(e->eEventType==MFP_EVENT_TYPE_MEDIAITEM_SET)PostMessage(win,WM_MEDIASET,0,0);}
static IMFPMediaPlayerCallbackVtbl callbackTable={cbQuery,cbAdd,cbRelease,cbEvent};
static IMFPMediaPlayerCallback callback={&callbackTable};
static void togglePlayback(void){if(mediaPlayer){MFP_MEDIAPLAYER_STATE state;IMFPMediaPlayer_GetState(mediaPlayer,&state);if(state==MFP_MEDIAPLAYER_STATE_PLAYING)IMFPMediaPlayer_Pause(mediaPlayer);else IMFPMediaPlayer_Play(mediaPlayer);}}
static LRESULT CALLBACK videoProc(HWND h,UINT m,WPARAM w,LPARAM l){if(m==WM_PAINT){PAINTSTRUCT ps;BeginPaint(h,&ps);if(mediaPlayer)IMFPMediaPlayer_UpdateVideo(mediaPlayer);EndPaint(h,&ps);return 0;}if(m==WM_SIZE&&mediaPlayer)IMFPMediaPlayer_UpdateVideo(mediaPlayer);if(m==WM_LBUTTONUP)togglePlayback();return DefWindowProc(h,m,w,l);}
static void playRendered(void){
 mediaStop();if(!mediaDLL)mediaDLL=LoadLibraryEx(L"mfplay.dll",NULL,LOAD_LIBRARY_SEARCH_SYSTEM32);
 if(!mediaDLL){error(L"Windows video playback is unavailable. Install the Windows Media Feature Pack if your Windows edition requires it. Frame previews and export still work.");return;}
 typedef HRESULT (WINAPI *CreatePlayer)(LPCWSTR,BOOL,MFP_CREATION_OPTIONS,IMFPMediaPlayerCallback*,HWND,IMFPMediaPlayer**);
 CreatePlayer create=(CreatePlayer)(void*)GetProcAddress(mediaDLL,"MFPCreateMediaPlayer");if(!create){error(L"Windows playback could not be initialized.");return;}
 HRESULT hr=create(NULL,FALSE,0,&callback,video,&mediaPlayer);IMFPMediaItem *item=NULL;wchar_t path[PATHLEN];pathjoin(path,L"playback.mp4");
 if(SUCCEEDED(hr))hr=IMFPMediaPlayer_CreateMediaItemFromURL(mediaPlayer,path,TRUE,0,&item);
 if(SUCCEEDED(hr))hr=IMFPMediaPlayer_SetMediaItem(mediaPlayer,item);if(item)IMFPMediaItem_Release(item);
 if(FAILED(hr)){mediaStop();error(L"Could not open the rendered preview in Windows. Frame previews and export remain available.");return;}
 ShowWindow(video,SW_SHOW);SetWindowText(status,L"Preview plays in the app. Click the video to pause/resume; Stop closes playback.");
}
static void effectsFilter(const Clip *c,wchar_t *out,int n){out[0]=0;
 if(c->rotation==1)wcscat(out,L"transpose=clock,");else if(c->rotation==2)wcscat(out,L"hflip,vflip,");else if(c->rotation==3)wcscat(out,L"transpose=cclock,");
 if(c->flip)wcscat(out,L"hflip,");
 if(c->effect==1)wcscat(out,L"hue=s=0,");else if(c->effect==2)wcscat(out,L"eq=brightness=0.04:saturation=1.2:contrast=1.08,");else if(c->effect==3)wcscat(out,L"negate,");(void)n;
}
static void refresh(void){
 mediaStop();
 SendMessage(list,LB_RESETCONTENT,0,0);for(int i=0;i<count;i++){wchar_t s[2200];swprintf(s,2200,L"%02d   %ls   [%.2f - %.2f s]%ls",i+1,basename(clips[i].path),clips[i].in,clips[i].out,clips[i].mute?L"  MUTED":L"");SendMessage(list,LB_ADDSTRING,0,(LPARAM)s);}
 if(selected>=count)selected=count-1;if(selected>=0){SendMessage(list,LB_SETCURSEL,selected,0);wchar_t s[64];swprintf(s,64,L"%.3f",clips[selected].in);SetWindowText(inbox,s);swprintf(s,64,L"%.3f",clips[selected].out);SetWindowText(outbox,s);SendMessage(mute,BM_SETCHECK,clips[selected].mute?BST_CHECKED:BST_UNCHECKED,0);
 SendMessage(GetDlgItem(win,EFFECT),CB_SETCURSEL,clips[selected].effect,0);SendMessage(GetDlgItem(win,ROTATE),CB_SETCURSEL,clips[selected].rotation,0);SendMessage(GetDlgItem(win,FLIP),BM_SETCHECK,clips[selected].flip?BST_CHECKED:BST_UNCHECKED,0);
 swprintf(s,64,L"%d",clips[selected].gain);SetWindowText(GetDlgItem(win,VOLUME),s);swprintf(s,64,L"%.2f",clips[selected].fadeIn);SetWindowText(GetDlgItem(win,FADEIN),s);swprintf(s,64,L"%.2f",clips[selected].fadeOut);SetWindowText(GetDlgItem(win,FADEOUT),s);
 if(playhead<clips[selected].in||playhead>clips[selected].out)playhead=clips[selected].in;
 SendMessage(GetDlgItem(win,SEEK),TBM_SETPOS,TRUE,(LPARAM)(1000*playhead/clips[selected].duration));}else{SetWindowText(inbox,L"0");SetWindowText(outbox,L"0");}
 InvalidateRect(win,&timelineRect,TRUE);
}
static void setBusy(int yes){busy=yes;for(int id=ADD;id<=STOP;id++){HWND c=GetDlgItem(win,id);if(c)EnableWindow(c,!yes);}EnableWindow(GetDlgItem(win,CANCEL),yes);}
static int numeric(HWND h,double *out){wchar_t s[128],*end;GetWindowText(h,s,128);*out=wcstod(s,&end);while(*end==L' ')end++;return end!=s&&!*end&&isfinite(*out);}
static int apply(void){if(selected<0)return 0;double a,b,g,fi,fo;
 if(!numeric(inbox,&a)||!numeric(outbox,&b)||a<0||b<=a||b>clips[selected].duration+.01){error(L"Enter Start / End in seconds, within the original clip. End must be after Start.");return 0;}
 if(!numeric(GetDlgItem(win,VOLUME),&g)||g<0||g>200||!numeric(GetDlgItem(win,FADEIN),&fi)||fi<0||!numeric(GetDlgItem(win,FADEOUT),&fo)||fo<0||fi+fo>(b-a)/2){error(L"Volume must be 0-200%. Fades use output seconds; their combined length must be no greater than half the trimmed source length, so they also fit at 2x speed.");return 0;}
 Clip next=clips[selected];next.in=a;next.out=b;next.mute=SendMessage(mute,BM_GETCHECK,0,0)==BST_CHECKED;next.effect=SendMessage(GetDlgItem(win,EFFECT),CB_GETCURSEL,0,0);next.rotation=SendMessage(GetDlgItem(win,ROTATE),CB_GETCURSEL,0,0);next.flip=SendMessage(GetDlgItem(win,FLIP),BM_GETCHECK,0,0)==BST_CHECKED;next.gain=(int)g;next.fadeIn=fi;next.fadeOut=fo;
 if(memcmp(&next,&clips[selected],sizeof(Clip))){checkpoint();clips[selected]=next;}refresh();return 1;
}
static int previewFrame(const Clip *c){wchar_t args[8192],bmp[PATHLEN],log[PATHLEN],fx[512];effectsFilter(c,fx,512);pathjoin(bmp,L"preview.bmp");pathjoin(log,L"preview.log");DeleteFile(bmp);
 swprintf(args,8192,L"-hide_banner -nostdin -y -ss %.6f -i \"%ls\" -frames:v 1 -vf \"%lsscale=560:315:force_original_aspect_ratio=decrease,pad=560:315:(ow-iw)/2:(oh-ih)/2\" -c:v bmp \"%ls\"",c->in,c->path,fx,bmp);
 if(run(engine,args,log)==0){HBITMAP b=LoadImage(NULL,bmp,IMAGE_BITMAP,0,0,LR_LOADFROMFILE);PostMessage(win,WM_FRAME,0,(LPARAM)b);return b!=NULL;}return 0;}
static int probe(Clip *c){wchar_t args[8192],log[PATHLEN];pathjoin(log,L"probe.log");swprintf(args,8192,L"-hide_banner -nostdin -i \"%ls\"",c->path);run(engine,args,log);char *s=readlog(log);if(!s)return 0;char *d=strstr(s,"Duration:");int h=0,m=0;double sec=0;int ok=d&&sscanf(d,"Duration: %d:%d:%lf",&h,&m,&sec)==3&&strstr(s,"Video:");c->audio=strstr(s,"Audio:")!=NULL;free(s);c->duration=h*3600+m*60+sec;c->in=0;c->out=c->duration;c->gain=100;return ok&&c->duration>0&&c->duration<864000;}
static int exportVideo(Job *j){
 wchar_t args[20000],log[PATHLEN],seg[PATHLEN],vf[2048],af[1024],msg[512],concat[PATHLEN];pathjoin(log,L"export.log");pathjoin(concat,L"concat.txt");FILE *f=_wfopen(concat,L"wb");if(!f)return 0;
 for(int i=0;i<j->count;i++){
  if(cancelled){fclose(f);return 0;}Clip *c=&j->clips[i];swprintf(msg,512,L"Exporting clip %d of %d...  Cancel stops the export.",i+1,j->count);setStatus(msg);
  wchar_t name[64];swprintf(name,64,L"segment%03d.mp4",i);pathjoin(seg,name);fprintf(f,"file 'segment%03d.mp4'\n",i);
  double duration=(c->out-c->in)/j->speed;
  wchar_t fx[512];effectsFilter(c,fx,512);
  swprintf(vf,2048,L"%lssetpts=(PTS-STARTPTS)/%.6f,scale=%d:%d:force_original_aspect_ratio=decrease,pad=%d:%d:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=%d,format=yuv420p",fx,j->speed,j->width,j->height,j->width,j->height,j->fps);
  swprintf(af,1024,L"asetpts=PTS-STARTPTS,atempo=%.6f,volume=%.3f",j->speed,c->mute?0:c->gain/100.0);
  wchar_t fade[256];if(c->fadeIn>0){swprintf(fade,256,L",fade=t=in:st=0:d=%.3f",c->fadeIn);wcscat(vf,fade);swprintf(fade,256,L",afade=t=in:st=0:d=%.3f",c->fadeIn);wcscat(af,fade);}
  if(c->fadeOut>0){swprintf(fade,256,L",fade=t=out:st=%.3f:d=%.3f",fmax(0,duration-c->fadeOut),c->fadeOut);wcscat(vf,fade);swprintf(fade,256,L",afade=t=out:st=%.3f:d=%.3f",fmax(0,duration-c->fadeOut),c->fadeOut);wcscat(af,fade);}
  if(c->audio)swprintf(args,20000,L"-hide_banner -nostdin -y -ss %.6f -t %.6f -i \"%ls\" -map 0:v:0 -map 0:a:0 -vf \"%ls\" -af \"%ls\" -t %.6f -c:v libx264 -preset veryfast -crf %d -c:a aac -ar 48000 -ac 2 -b:a 160k -video_track_timescale 15360 \"%ls\"",c->in,c->out-c->in,c->path,vf,af,duration,j->crf?j->crf:20,seg);
  else swprintf(args,20000,L"-hide_banner -nostdin -y -ss %.6f -t %.6f -i \"%ls\" -f lavfi -t %.6f -i anullsrc=r=48000:cl=stereo -map 0:v:0 -map 1:a:0 -vf \"%ls\" -t %.6f -c:v libx264 -preset veryfast -crf %d -c:a aac -ar 48000 -ac 2 -b:a 160k -video_track_timescale 15360 \"%ls\"",c->in,c->out-c->in,c->path,duration,vf,duration,j->crf?j->crf:20,seg);
  if(run(engine,args,log)!=0){fclose(f);return 0;}
 }
 fclose(f);if(cancelled)return 0;setStatus(L"Combining clips and finishing MP4...");
 wchar_t staging[PATHLEN];swprintf(staging,PATHLEN,L"%ls.novacut-%lu-%lu.mp4",j->output,GetCurrentProcessId(),GetTickCount());
 swprintf(args,20000,L"-hide_banner -nostdin -n -f concat -safe 1 -i \"%ls\" -c copy -movflags +faststart \"%ls\"",concat,staging);
 int ok=run(engine,args,log)==0&&!cancelled;
 if(ok)ok=MoveFileEx(staging,j->output,MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH);
 if(!ok)DeleteFile(staging);
 for(int i=0;i<j->count;i++){wchar_t name[64];swprintf(name,64,L"segment%03d.mp4",i);pathjoin(seg,name);DeleteFile(seg);}return ok;
}
static DWORD WINAPI workThread(void *arg){Job *j=arg;int ok=1;
 if(j->type==1){for(int i=0;i<j->count;i++){if(cancelled)break;wchar_t s[2300];swprintf(s,2300,L"Reading %ls...",basename(j->clips[i].path));setStatus(s);if(probe(&j->clips[i])){Clip *c=malloc(sizeof(Clip));*c=j->clips[i];PostMessage(win,WM_IMPORTED,0,(LPARAM)c);}else{swprintf(s,2300,L"Skipped unsupported or unreadable file: %ls",basename(j->clips[i].path));setStatus(s);}}}
 if(j->type==2)ok=previewFrame(&j->clips[0]);
 if(j->type==3||j->type==4)ok=exportVideo(j);
 if(j->type==5){wchar_t args[8192],log[PATHLEN],fx[512];pathjoin(log,L"snapshot.log");effectsFilter(&j->clips[0],fx,512);wcscat(fx,L"null");swprintf(args,8192,L"-hide_banner -nostdin -y -ss %.6f -i \"%ls\" -frames:v 1 -vf \"%ls\" -c:v png \"%ls\"",j->clips[0].in,j->clips[0].path,fx,j->output);ok=run(engine,args,log)==0;}
 int type=j->type;free(j);PostMessage(win,WM_DONE,type,ok);return 0;
}
static void launch(Job *j){InterlockedExchange(&cancelled,0);setBusy(1);worker=CreateThread(NULL,0,workThread,j,0,NULL);if(!worker){free(j);setBusy(0);error(L"Could not start worker.");}}
static void snapshot(void){if(selected<0)return;Job *j=calloc(1,sizeof(Job));j->type=2;j->clips[0]=clips[selected];j->clips[0].in=fmin(playhead,fmax(0,clips[selected].duration-.04));mediaStop();setStatus(L"Preparing preview frame...");launch(j);}
static int dialog(wchar_t *path,int save,const wchar_t *filter,const wchar_t *ext){OPENFILENAME o={0};o.lStructSize=sizeof(o);o.hwndOwner=win;o.lpstrFilter=filter;o.lpstrFile=path;o.nMaxFile=PATHLEN;o.lpstrDefExt=ext;o.Flags=OFN_EXPLORER|OFN_NOCHANGEDIR|OFN_PATHMUSTEXIST|(save?OFN_OVERWRITEPROMPT:OFN_FILEMUSTEXIST);return save?GetSaveFileName(&o):GetOpenFileName(&o);}
static void add(void){if(count>=MAXCLIPS){error(L"This version supports up to 64 clips.");return;}wchar_t buf[32768]={0};OPENFILENAME o={0};o.lStructSize=sizeof(o);o.hwndOwner=win;o.lpstrFilter=L"Video files\0*.mp4;*.mov;*.mkv;*.avi;*.webm;*.m4v;*.wmv\0All files\0*.*\0";o.lpstrFile=buf;o.nMaxFile=32768;o.Flags=OFN_EXPLORER|OFN_ALLOWMULTISELECT|OFN_FILEMUSTEXIST|OFN_NOCHANGEDIR;if(!GetOpenFileName(&o))return;
 Job *j=calloc(1,sizeof(Job));j->type=1;wchar_t *p=buf+wcslen(buf)+1;if(!*p){wcsncpy(j->clips[0].path,buf,PATHLEN-1);j->count=1;}else{while(*p&&j->count<MAXCLIPS-count){if(wcslen(buf)+wcslen(p)+2<PATHLEN){swprintf(j->clips[j->count].path,PATHLEN,L"%ls\\%ls",buf,p);j->count++;}p+=wcslen(p)+1;}}launch(j);
}
static void play(void){if(!apply())return;mediaStop();Job *j=calloc(1,sizeof(Job));j->type=4;j->count=1;j->clips[0]=clips[selected];if(playhead>=j->clips[0].in&&playhead<j->clips[0].out)j->clips[0].in=playhead;j->clips[0].out=fmin(j->clips[0].out,j->clips[0].in+20);j->clips[0].fadeIn=fmin(j->clips[0].fadeIn,(j->clips[0].out-j->clips[0].in)/4);j->clips[0].fadeOut=fmin(j->clips[0].fadeOut,(j->clips[0].out-j->clips[0].in)/4);j->width=640;j->height=360;j->fps=30;j->crf=28;int idx=SendMessage(speed,CB_GETCURSEL,0,0);j->speed=idx==0?.5:idx==2?2:1;pathjoin(j->output,L"playback.mp4");setStatus(L"Rendering preview (up to 20 source seconds), including edits...");launch(j);}
static void pngSnapshot(void){if(!apply())return;wchar_t out[PATHLEN]=L"NovaCut-frame.png";if(!dialog(out,1,L"PNG image\0*.png\0",L"png"))return;for(int i=0;i<count;i++)if(!_wcsicmp(out,clips[i].path)){error(L"Choose a different file from your original video.");return;}Job *j=calloc(1,sizeof(Job));j->type=5;j->clips[0]=clips[selected];j->clips[0].in=fmin(playhead,fmax(0,clips[selected].duration-.04));wcscpy(j->output,out);launch(j);}
static void history(int redo){State current;capture(&current);State next;if(redo){if(!redoCount)return;next=redoStates[--redoCount];if(undoCount<24)undoStates[undoCount++]=current;}else{if(!undoCount)return;next=undoStates[--undoCount];if(redoCount<24)redoStates[redoCount++]=current;}memcpy(clips,next.clips,sizeof(clips));count=next.count;selected=next.selected;playhead=selected>=0?clips[selected].in:0;refresh();if(selected>=0)snapshot();}
static void duplicateClip(void){if(selected<0||count>=MAXCLIPS||!apply())return;checkpoint();memmove(&clips[selected+2],&clips[selected+1],(count-selected-1)*sizeof(Clip));clips[selected+1]=clips[selected];count++;selected++;refresh();}
static void splitClip(void){if(selected<0||count>=MAXCLIPS||!apply())return;if(playhead<=clips[selected].in+.01||playhead>=clips[selected].out-.01){error(L"Move the playhead inside the trimmed clip before splitting.");return;}checkpoint();memmove(&clips[selected+2],&clips[selected+1],(count-selected-1)*sizeof(Clip));clips[selected+1]=clips[selected];clips[selected].out=playhead;clips[selected+1].in=playhead;clips[selected].fadeIn=clips[selected].fadeOut=0;clips[selected+1].fadeIn=clips[selected+1].fadeOut=0;count++;refresh();}
static void saveProject(void){if(selected>=0&&!apply())return;wchar_t path[PATHLEN]={0};if(!dialog(path,1,L"NovaCut project\0*.ncut\0",L"ncut"))return;for(int i=0;i<count;i++)if(!_wcsicmp(path,clips[i].path)){error(L"Choose a project file separate from your source video.");return;}FILE *f=_wfopen(path,L"wb");if(!f){error(L"Could not write project.");return;}unsigned header[5]={0x4e435554,2,(unsigned)count,(unsigned)SendMessage(res,CB_GETCURSEL,0,0),(unsigned)SendMessage(fps,CB_GETCURSEL,0,0)};int sp=SendMessage(speed,CB_GETCURSEL,0,0);int q=SendMessage(GetDlgItem(win,QUALITY),CB_GETCURSEL,0,0);int ok=fwrite(header,sizeof(header),1,f)==1&&fwrite(&sp,sizeof(sp),1,f)==1&&fwrite(clips,sizeof(Clip),count,f)==(size_t)count&&fwrite(&q,sizeof(q),1,f)==1;ok=fclose(f)==0&&ok;if(!ok)error(L"Project could not be saved completely.");else SetWindowText(status,L"Project saved. Keep the original video files in their current locations.");}
static void openProject(void){wchar_t path[PATHLEN]={0};if(!dialog(path,0,L"NovaCut project\0*.ncut\0",L"ncut"))return;FILE *f=_wfopen(path,L"rb");if(!f)return;unsigned h[5]={0};int sp=1;Clip temp[MAXCLIPS]={0};int ok=fread(h,sizeof(h),1,f)==1&&h[0]==0x4e435554&&(h[1]==1||h[1]==2)&&h[2]<=MAXCLIPS&&h[3]<5&&h[4]<3&&fread(&sp,sizeof(sp),1,f)==1&&sp>=0&&sp<3;
 if(ok&&h[1]==1){for(unsigned i=0;i<h[2];i++){OldClip c;if(fread(&c,sizeof(c),1,f)!=1){ok=0;break;}memcpy(&temp[i],&c,sizeof(c));temp[i].gain=100;}}else if(ok)ok=fread(temp,sizeof(Clip),h[2],f)==h[2];int q=1;if(ok&&h[1]==2){if(fread(&q,sizeof(q),1,f)!=1)q=1;if(q<0||q>2)ok=0;}fclose(f);
 if(ok)for(unsigned i=0;i<h[2];i++){Clip *c=&temp[i];if(!wmemchr(c->path,0,PATHLEN)||!isfinite(c->duration)||!isfinite(c->in)||!isfinite(c->out)||!isfinite(c->fadeIn)||!isfinite(c->fadeOut)||c->in<0||c->out<=c->in||c->out>c->duration+.01||c->gain<0||c->gain>200||c->effect<0||c->effect>3||c->rotation<0||c->rotation>3||c->fadeIn<0||c->fadeOut<0||c->fadeIn+c->fadeOut>(c->out-c->in)/2+.01||GetFileAttributes(c->path)==INVALID_FILE_ATTRIBUTES){ok=0;break;}}
 if(!ok){error(L"Invalid project or missing original video. Version 1 and 2 projects are supported.");return;}checkpoint();count=h[2];memcpy(clips,temp,count*sizeof(Clip));selected=count?0:-1;playhead=selected>=0?clips[0].in:0;SendMessage(res,CB_SETCURSEL,h[3],0);SendMessage(fps,CB_SETCURSEL,h[4],0);SendMessage(speed,CB_SETCURSEL,sp,0);SendMessage(GetDlgItem(win,QUALITY),CB_SETCURSEL,q,0);refresh();if(selected>=0)snapshot();}
static void exportStart(void){if(!count){error(L"Add at least one video first.");return;}if(!apply())return;wchar_t out[PATHLEN]=L"NovaCut-export.mp4";if(!dialog(out,1,L"MP4 video\0*.mp4\0",L"mp4"))return;wchar_t full[PATHLEN];GetFullPathName(out,PATHLEN,full,NULL);for(int i=0;i<count;i++){wchar_t src[PATHLEN];GetFullPathName(clips[i].path,PATHLEN,src,NULL);if(!_wcsicmp(full,src)){error(L"Choose a different output file. Export cannot overwrite an original video.");return;}}
 Job *j=calloc(1,sizeof(Job));j->type=3;j->count=count;memcpy(j->clips,clips,count*sizeof(Clip));wcscpy(j->output,out);int r=SendMessage(res,CB_GETCURSEL,0,0);j->width=r==0?854:r==1?1280:r==2?1920:r==3?2560:3840;j->height=r==0?480:r==1?720:r==2?1080:r==3?1440:2160;j->crf=SendMessage(GetDlgItem(win,QUALITY),CB_GETCURSEL,0,0)==0?28:SendMessage(GetDlgItem(win,QUALITY),CB_GETCURSEL,0,0)==2?18:23;int rate=SendMessage(fps,CB_GETCURSEL,0,0);j->fps=rate==0?24:rate==1?30:60;int sp=SendMessage(speed,CB_GETCURSEL,0,0);j->speed=sp==0?.5:sp==2?2:1;launch(j);}
static HWND control(const wchar_t *cls,const wchar_t *text,DWORD style,int id){if(!wcscmp(cls,L"BUTTON")&&(style&BS_TYPEMASK)==BS_PUSHBUTTON)style=(style&~BS_TYPEMASK)|BS_OWNERDRAW;HWND h=CreateWindowEx(wcscmp(cls,WC_EDIT)==0?WS_EX_CLIENTEDGE:0,cls,text,WS_CHILD|WS_VISIBLE|(!wcscmp(cls,L"STATIC")?0:WS_TABSTOP)|style,0,0,0,0,win,(HMENU)(INT_PTR)id,instance,NULL);SendMessage(h,WM_SETFONT,(WPARAM)font,TRUE);return h;}
static void move(int id,int x,int y,int w,int h){MoveWindow(GetDlgItem(win,id),x,y,w,h,TRUE);}
static void label(int id,const wchar_t *text){control(L"STATIC",text,SS_LEFT,id);}
static void layout(int w,int h){
 int lx=20,lw=244,ix=w-294,iw=274,cx=284,cw=ix-cx-20;
 move(201,22,15,400,34);move(202,23,54,470,22);
 move(ADD,23,85,133,32);move(OPEN,167,85,119,32);move(SAVE,297,85,119,32);move(UNDO,w-380,34,82,32);move(REDO,w-288,34,82,32);move(HELP,w-122,34,100,32);
 move(203,lx+14,139,lw-28,24);move(CLIPLIST,lx+12,174,lw-24,h-490);
 move(REMOVE,lx+12,h-303,70,30);move(UP,lx+88,h-303,70,30);move(DOWN,lx+164,h-303,68,30);move(DUPLICATE,lx+12,h-262,104,30);move(SPLIT,lx+126,h-262,106,30);
 move(204,cx+14,139,cw-28,24);frameRect=(RECT){cx+12,175,cx+cw-12,h-293};if(video)MoveWindow(video,frameRect.left,frameRect.top,frameRect.right-frameRect.left,frameRect.bottom-frameRect.top,TRUE);
 move(SEEK,cx+12,h-285,cw-24,28);move(PLAY,cx+12,h-244,104,30);move(STOP,cx+126,h-244,65,30);move(PNG,cx+201,h-244,140,30);
 move(227,ix+14,139,iw-28,25);move(205,ix+14,178,112,22);move(206,ix+144,178,116,22);
 move(INBOX,ix+14,203,112,30);move(OUTBOX,ix+144,203,116,30);move(MARKIN,ix+14,243,112,29);move(MARKOUT,ix+144,243,116,29);
 move(220,ix+14,286,116,22);move(221,ix+144,286,116,22);move(EFFECT,ix+14,311,116,160);move(ROTATE,ix+144,311,116,160);move(FLIP,ix+14,355,120,25);move(MUTE,ix+144,355,116,25);
 move(222,ix+14,395,116,22);move(VOLUME,ix+144,390,116,30);move(223,ix+14,440,116,22);move(224,ix+144,440,116,22);move(FADEIN,ix+14,465,116,30);move(FADEOUT,ix+144,465,116,30);move(225,ix+14,506,iw-28,40);move(APPLY,ix+14,h-244,iw-28,32);
 move(210,26,h-190,w-52,22);timelineRect=(RECT){20,h-161,w-20,h-92};
 move(207,23,h-69,74,22);move(RES,97,h-74,95,160);move(208,208,h-69,35,22);move(FPS,243,h-74,65,120);move(209,326,h-69,49,22);move(SPEED,375,h-74,73,120);move(226,466,h-69,59,22);move(QUALITY,525,h-74,132,120);move(EXPORT,w-179,h-74,159,33);move(CANCEL,w-275,h-74,85,33);
 move(211,23,h-28,65,21);move(212,91,h-28,w-112,21);InvalidateRect(win,NULL,TRUE);
}
static void surface(HDC dc,RECT r){HBRUSH b=CreateSolidBrush(RGB(25,35,49));HPEN pen=CreatePen(PS_SOLID,1,RGB(43,56,73));HGDIOBJ oldb=SelectObject(dc,b),oldp=SelectObject(dc,pen);RoundRect(dc,r.left,r.top,r.right,r.bottom,14,14);SelectObject(dc,oldb);SelectObject(dc,oldp);DeleteObject(b);DeleteObject(pen);}
static void paint(HDC dc){RECT r;GetClientRect(win,&r);FillRect(dc,&r,bg);surface(dc,(RECT){20,128,264,r.bottom-204});surface(dc,(RECT){284,128,r.right-314,r.bottom-204});surface(dc,(RECT){r.right-294,128,r.right-20,r.bottom-204});FillRect(dc,&frameRect,panel);SetBkMode(dc,TRANSPARENT);SetTextColor(dc,RGB(164,179,198));SelectObject(dc,font);
 if(frame){BITMAP b;GetObject(frame,sizeof(b),&b);HDC mem=CreateCompatibleDC(dc);HGDIOBJ old=SelectObject(mem,frame);int aw=frameRect.right-frameRect.left,ah=frameRect.bottom-frameRect.top;double s=fmin((double)aw/b.bmWidth,(double)ah/b.bmHeight);int pw=b.bmWidth*s,ph=b.bmHeight*s;SetStretchBltMode(dc,HALFTONE);StretchBlt(dc,frameRect.left+(aw-pw)/2,frameRect.top+(ah-ph)/2,pw,ph,mem,0,0,b.bmWidth,b.bmHeight,SRCCOPY);SelectObject(mem,old);DeleteDC(mem);}else{RECT t=frameRect;DrawText(dc,L"Add a video, then select a clip.\nPreview frame appears here.",-1,&t,DT_CENTER|DT_VCENTER|DT_WORDBREAK);}
 FillRect(dc,&timelineRect,panel);double total=length();if(count&&total>0){int x=timelineRect.left;for(int i=0;i<count;i++){int width=(int)((timelineRect.right-timelineRect.left)*(clips[i].out-clips[i].in)/total);RECT t={x+2,timelineRect.top+5,x+width-2,timelineRect.bottom-5};HBRUSH b=CreateSolidBrush(i==selected?RGB(52,173,161):RGB(48,82,122));FillRect(dc,&t,b);DeleteObject(b);SetTextColor(dc,RGB(255,255,255));wchar_t s[64];swprintf(s,64,L"%d\n%.1fs",i+1,clips[i].out-clips[i].in);DrawText(dc,s,-1,&t,DT_CENTER|DT_WORDBREAK);x+=width;}}else{RECT t=timelineRect;DrawText(dc,L"Your clips play from left to right.",-1,&t,DT_CENTER|DT_VCENTER|DT_SINGLELINE);}}
static void cancelJob(void){InterlockedExchange(&cancelled,1);EnterCriticalSection(&processLock);if(child)TerminateProcess(child,1);LeaveCriticalSection(&processLock);SetWindowText(status,L"Cancelling...");}
static void cleanup(void){mediaStop();if(mediaDLL)FreeLibrary(mediaDLL);wchar_t pat[PATHLEN],p[PATHLEN];pathjoin(pat,L"*");WIN32_FIND_DATA d;HANDLE h=FindFirstFile(pat,&d);if(h!=INVALID_HANDLE_VALUE){do{if(!(d.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)){pathjoin(p,d.cFileName);DeleteFile(p);}}while(FindNextFile(h,&d));FindClose(h);}RemoveDirectory(work);}
static LRESULT CALLBACK proc(HWND h,UINT m,WPARAM w,LPARAM l){switch(m){
 case WM_CREATE:{win=h;font=CreateFont(-17,0,0,0,FW_NORMAL,0,0,0,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Segoe UI");titleFont=CreateFont(-28,0,0,0,FW_BOLD,0,0,0,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Segoe UI");bg=CreateSolidBrush(RGB(15,21,30));panel=CreateSolidBrush(RGB(21,29,42));card=CreateSolidBrush(RGB(25,35,49));
 label(201,L"NovaCut");SendMessage(GetDlgItem(h,201),WM_SETFONT,(WPARAM)titleFont,0);label(202,L"Small editor. Full control.   Everything runs on your PC.");
 control(L"BUTTON",L"+ Add videos",BS_PUSHBUTTON,ADD);control(L"BUTTON",L"Open project",0,OPEN);control(L"BUTTON",L"Save project",0,SAVE);control(L"BUTTON",L"Help",0,HELP);control(L"BUTTON",L"Undo",0,UNDO);control(L"BUTTON",L"Redo",0,REDO);
 label(203,L"CLIPS");list=control(L"LISTBOX",L"",LBS_NOTIFY|WS_VSCROLL|WS_HSCROLL|WS_BORDER,CLIPLIST);SendMessage(list,LB_SETHORIZONTALEXTENT,1800,0);
 control(L"BUTTON",L"Remove",0,REMOVE);control(L"BUTTON",L"Up",0,UP);control(L"BUTTON",L"Down",0,DOWN);control(L"BUTTON",L"Duplicate",0,DUPLICATE);control(L"BUTTON",L"Split",0,SPLIT);label(204,L"PREVIEW  /  Drag to seek. Click playback to pause.");
 label(205,L"Start (sec)");inbox=control(L"EDIT",L"0",ES_AUTOHSCROLL,INBOX);label(206,L"End");outbox=control(L"EDIT",L"0",ES_AUTOHSCROLL,OUTBOX);mute=control(L"BUTTON",L"Mute clip",BS_AUTOCHECKBOX,MUTE);control(L"BUTTON",L"Apply changes",0,APPLY);control(L"BUTTON",L"Play 20s",0,PLAY);
 control(L"BUTTON",L"Set start",0,MARKIN);control(L"BUTTON",L"Set end",0,MARKOUT);control(L"BUTTON",L"Stop",0,STOP);control(L"BUTTON",L"Save PNG frame",0,PNG);
 control(TRACKBAR_CLASS,L"",TBS_HORZ|TBS_NOTICKS,SEEK);SendMessage(GetDlgItem(h,SEEK),TBM_SETRANGE,TRUE,MAKELPARAM(0,1000));
 label(227,L"CLIP SETTINGS");label(220,L"Color");HWND e=control(L"COMBOBOX",L"",CBS_DROPDOWNLIST,EFFECT);const wchar_t *effects[]={L"Original",L"Grayscale",L"Vivid",L"Invert"};for(int k=0;k<4;k++)SendMessage(e,CB_ADDSTRING,0,(LPARAM)effects[k]);SendMessage(e,CB_SETCURSEL,0,0);
 label(221,L"Rotate");e=control(L"COMBOBOX",L"",CBS_DROPDOWNLIST,ROTATE);const wchar_t *rot[]={L"0 degrees",L"90 degrees",L"180 degrees",L"270 degrees"};for(int k=0;k<4;k++)SendMessage(e,CB_ADDSTRING,0,(LPARAM)rot[k]);SendMessage(e,CB_SETCURSEL,0,0);control(L"BUTTON",L"Mirror",BS_AUTOCHECKBOX,FLIP);
 label(222,L"Volume %");control(L"EDIT",L"100",ES_AUTOHSCROLL,VOLUME);label(223,L"Fade in s");control(L"EDIT",L"0",ES_AUTOHSCROLL,FADEIN);label(224,L"Fade out s");control(L"EDIT",L"0",ES_AUTOHSCROLL,FADEOUT);label(225,L"Fades affect video and audio.\nValues are output seconds.");
 label(226,L"Quality");e=control(L"COMBOBOX",L"",CBS_DROPDOWNLIST,QUALITY);SendMessage(e,CB_ADDSTRING,0,(LPARAM)L"Smaller file");SendMessage(e,CB_ADDSTRING,0,(LPARAM)L"Balanced");SendMessage(e,CB_ADDSTRING,0,(LPARAM)L"Higher quality");SendMessage(e,CB_SETCURSEL,1,0);
 video=CreateWindow(L"NovaCutVideo",L"",WS_CHILD,0,0,0,0,h,NULL,instance,NULL);
 label(207,L"Resolution");res=control(L"COMBOBOX",L"",CBS_DROPDOWNLIST|WS_VSCROLL,RES);SendMessage(res,CB_ADDSTRING,0,(LPARAM)L"480p");SendMessage(res,CB_ADDSTRING,0,(LPARAM)L"720p");SendMessage(res,CB_ADDSTRING,0,(LPARAM)L"1080p");SendMessage(res,CB_ADDSTRING,0,(LPARAM)L"1440p");SendMessage(res,CB_ADDSTRING,0,(LPARAM)L"4K");SendMessage(res,CB_SETCURSEL,1,0);
 label(208,L"FPS");fps=control(L"COMBOBOX",L"",CBS_DROPDOWNLIST,FPS);SendMessage(fps,CB_ADDSTRING,0,(LPARAM)L"24");SendMessage(fps,CB_ADDSTRING,0,(LPARAM)L"30");SendMessage(fps,CB_ADDSTRING,0,(LPARAM)L"60");SendMessage(fps,CB_SETCURSEL,1,0);
 label(209,L"Speed");speed=control(L"COMBOBOX",L"",CBS_DROPDOWNLIST,SPEED);SendMessage(speed,CB_ADDSTRING,0,(LPARAM)L"0.5x");SendMessage(speed,CB_ADDSTRING,0,(LPARAM)L"1x");SendMessage(speed,CB_ADDSTRING,0,(LPARAM)L"2x");SendMessage(speed,CB_SETCURSEL,1,0);
 control(L"BUTTON",L"Export MP4",0,EXPORT);control(L"BUTTON",L"Cancel",0,CANCEL);EnableWindow(GetDlgItem(h,CANCEL),FALSE);label(210,L"TIMELINE  /  Clips export from left to right");label(211,L"Ready");label(212,L"Ready. Add videos to begin.");status=GetDlgItem(h,212);return 0;}
 case WM_SIZE:layout(LOWORD(l),HIWORD(l));return 0;
 case WM_GETMINMAXINFO:((MINMAXINFO*)l)->ptMinTrackSize=(POINT){1120,840};return 0;
 case WM_CTLCOLORBTN:case WM_CTLCOLORSTATIC:{HDC dc=(HDC)w;RECT childRect,client;GetWindowRect((HWND)l,&childRect);MapWindowPoints(NULL,h,(POINT*)&childRect,2);GetClientRect(h,&client);BOOL inside=childRect.top>=128&&childRect.bottom<=client.bottom-204;SetTextColor(dc,RGB(218,229,241));SetBkColor(dc,inside?RGB(25,35,49):RGB(15,21,30));return (LRESULT)(inside?card:bg);}
 case WM_CTLCOLORLISTBOX:case WM_CTLCOLOREDIT:{HDC dc=(HDC)w;SetTextColor(dc,RGB(235,243,251));SetBkColor(dc,RGB(21,29,42));return (LRESULT)panel;}
 case WM_DRAWITEM:{DRAWITEMSTRUCT *d=(DRAWITEMSTRUCT*)l;if(d->CtlType!=ODT_BUTTON)break;HDC dc=d->hDC;RECT r=d->rcItem;BOOL disabled=(d->itemState&ODS_DISABLED)!=0,pressed=(d->itemState&ODS_SELECTED)!=0;COLORREF color=disabled?RGB(29,38,50):(d->CtlID==EXPORT||d->CtlID==ADD||d->CtlID==APPLY)?(pressed?RGB(35,126,119):RGB(43,164,151)):(pressed?RGB(41,55,76):RGB(37,49,67));HBRUSH b=CreateSolidBrush(color);HPEN p=CreatePen(PS_SOLID,1,RGB(56,72,91));HGDIOBJ oldb=SelectObject(dc,b),oldp=SelectObject(dc,p),oldf=SelectObject(dc,font);RoundRect(dc,r.left,r.top,r.right,r.bottom,8,8);SetBkMode(dc,TRANSPARENT);SetTextColor(dc,disabled?RGB(108,121,139):RGB(239,247,250));wchar_t t[160];GetWindowText(d->hwndItem,t,160);DrawText(dc,t,-1,&r,DT_CENTER|DT_VCENTER|DT_SINGLELINE);if(d->itemState&ODS_FOCUS){InflateRect(&r,-4,-4);DrawFocusRect(dc,&r);}SelectObject(dc,oldb);SelectObject(dc,oldp);SelectObject(dc,oldf);DeleteObject(b);DeleteObject(p);return TRUE;}
 case WM_PAINT:{PAINTSTRUCT ps;HDC dc=BeginPaint(h,&ps);paint(dc);EndPaint(h,&ps);return 0;}
 case WM_STATUS:SetWindowText(status,(wchar_t*)l);free((void*)l);return 0;
 case WM_FRAME:if(frame)DeleteObject(frame);frame=(HBITMAP)l;InvalidateRect(h,&frameRect,TRUE);return 0;
 case WM_IMPORTED:if(count<MAXCLIPS){clips[count++]=*(Clip*)l;if(selected<0)selected=0;refresh();}free((void*)l);return 0;
 case WM_DONE:{if(worker){CloseHandle(worker);worker=NULL;}setBusy(0);int wasCancel=cancelled;InterlockedExchange(&cancelled,0);if(w==4){if(l&&!wasCancel)playRendered();else SetWindowText(status,L"Preview stopped or failed.");}else if(w==5){SetWindowText(status,l?L"PNG frame saved.":L"PNG save failed.");}else if(w==3){if(wasCancel)SetWindowText(status,L"Export cancelled. Your original videos were kept.");else if(l){SetWindowText(status,L"Export complete. Your MP4 is ready.");MessageBox(h,L"Your video was exported successfully.",L"NovaCut",MB_OK|MB_ICONINFORMATION);}else{SetWindowText(status,L"Export failed. Open Help for the export log.");error(L"Export failed. Check free disk space and input files. Help can open the export log.");}}else if(w==1){SetWindowText(status,L"Import finished. Select a clip, set Start and End, then Apply trim.");if(selected>=0)snapshot();}else SetWindowText(status,l?L"Ready. Play 20s previews edits; click the video to pause.":L"Preview frame failed. Check the video file.");return 0;}
 case WM_MEDIASET:if(mediaPlayer)IMFPMediaPlayer_Play(mediaPlayer);return 0;
 case WM_MEDIAERR:mediaStop();SetWindowText(status,L"Windows playback failed; frame previews and export are available.");return 0;
 case WM_HSCROLL:if((HWND)l==GetDlgItem(win,SEEK)&&selected>=0&&!busy){playhead=clips[selected].duration*SendMessage((HWND)l,TBM_GETPOS,0,0)/1000.0;wchar_t t[120];swprintf(t,120,L"Playhead: %.3f seconds. Set start/end, Split, or Save PNG frame.",playhead);SetWindowText(status,t);if(LOWORD(w)==TB_ENDTRACK)snapshot();}return 0;
 case WM_COMMAND:{int id=LOWORD(w);if(id==CANCEL){cancelJob();return 0;}if(busy)return 0;
 if(id==UNDO)history(0);if(id==REDO)history(1);if(id==DUPLICATE)duplicateClip();if(id==SPLIT)splitClip();if(id==PNG)pngSnapshot();if(id==STOP)mediaStop();if((id==MARKIN||id==MARKOUT)&&selected>=0){wchar_t t[64];swprintf(t,64,L"%.3f",playhead);SetWindowText(id==MARKIN?inbox:outbox,t);}
 if(id==ADD){checkpoint();add();}if(id==CLIPLIST&&HIWORD(w)==LBN_SELCHANGE){selected=SendMessage(list,LB_GETCURSEL,0,0);playhead=selected>=0?clips[selected].in:0;refresh();snapshot();}
 if(id==APPLY&&apply())snapshot();if(id==PLAY)play();if(id==REMOVE&&selected>=0){checkpoint();memmove(&clips[selected],&clips[selected+1],(count-selected-1)*sizeof(Clip));count--;if(selected>=count)selected=count-1;refresh();if(frame){DeleteObject(frame);frame=NULL;}InvalidateRect(h,&frameRect,TRUE);if(selected>=0)snapshot();}
 if((id==UP||id==DOWN)&&selected>=0){int n=selected+(id==UP?-1:1);if(n>=0&&n<count){checkpoint();Clip t=clips[n];clips[n]=clips[selected];clips[selected]=t;selected=n;refresh();}}
 if(id==SAVE)saveProject();if(id==OPEN)openProject();if(id==EXPORT)exportStart();
 if(id==HELP){int answer=MessageBox(h,L"NovaCut 2 - Compact Windows x64 editor\n\nAdd videos; select a clip; drag the playhead. Set start/end, color, rotation, mirror, volume, or fades, then Apply trim.\nSplit divides the clip at the playhead. Duplicate repeats it. Undo/Redo restores up to 24 edit states.\nPlay 20s renders an edited preview inside the app. Click the video to pause/resume. Save PNG frame captures the playhead at source resolution with color/rotation/mirror edits.\n\nExport joins clips in order, with sound. Choose 480p through 4K, 24/30/60 FPS, speed, and compression quality. Higher resolution and long videos take more time and temporary disk space.\n\nProjects reference original files; keep those files. Version 1 projects still open. Fades use output seconds.\n\nSingle EXE. No BAT, separate compiler, or downloads needed. The compact FFmpeg engine is bundled. Playback uses Windows Media Foundation.\n\nYES: Open export log. NO: Open licenses. CANCEL: Return.",L"NovaCut Help",MB_YESNOCANCEL|MB_ICONINFORMATION);wchar_t p[PATHLEN];if(answer==IDYES){pathjoin(p,L"export.log");ShellExecute(h,L"open",p,NULL,NULL,SW_SHOW);}if(answer==IDNO){pathjoin(p,L"LICENSE.txt");ShellExecute(h,L"open",p,NULL,NULL,SW_SHOW);}}return 0;}
 case WM_CLOSE:if(busy){cancelJob();SetWindowText(status,L"Cancelling. Close the editor after the task stops.");return 0;}DestroyWindow(h);return 0;
 case WM_DESTROY:cleanup();if(frame)DeleteObject(frame);DeleteObject(font);DeleteObject(titleFont);DeleteObject(bg);DeleteObject(panel);DeleteObject(card);PostQuitMessage(0);return 0;
 }return DefWindowProc(h,m,w,l);}
static int selftest(void){wchar_t log[PATHLEN],args[8192],video[PATHLEN];pathjoin(log,L"selftest.log");pathjoin(video,L"selftest.mp4");swprintf(args,8192,L"-hide_banner -nostdin -y -f lavfi -i testsrc2=size=320x180:rate=30 -f lavfi -i sine=frequency=440:sample_rate=48000 -t 2 -c:v libx264 -pix_fmt yuv420p -c:a aac \"%ls\"",video);if(run(engine,args,log))return 10;Clip c={0};wcscpy(c.path,video);if(!probe(&c)||!c.audio)return 11;Job *j=calloc(1,sizeof(Job));j->count=2;j->clips[0]=c;j->clips[0].in=.2;j->clips[0].out=1;j->clips[1]=c;j->clips[1].in=1;j->clips[1].out=1.8;j->clips[1].mute=1;j->width=854;j->height=480;j->fps=30;j->speed=2;pathjoin(j->output,L"selftest-export.mp4");int ok=exportVideo(j);Clip result={0};wcscpy(result.path,j->output);free(j);if(!ok||!probe(&result)||result.duration<.7||result.duration>1.1)return 12;return 0;}
int WINAPI wWinMain(HINSTANCE inst,HINSTANCE prev,LPWSTR cmd,int show){(void)prev;instance=inst;CoInitializeEx(NULL,COINIT_APARTMENTTHREADED);InitializeCriticalSection(&processLock);wchar_t tmp[PATHLEN];GetTempPath(PATHLEN,tmp);if(!GetTempFileName(tmp,L"NCT",0,work))return 1;DeleteFile(work);if(!CreateDirectory(work,NULL))return 1;pathjoin(engine,L"ffmpeg.exe");wchar_t license[PATHLEN];pathjoin(license,L"LICENSE.txt");if(!extract(1,engine)||!extract(3,license)){MessageBox(NULL,L"Could not unpack bundled rendering tools. Check available disk space.",L"NovaCut",MB_ICONERROR);cleanup();return 2;}if(wcsstr(cmd,L"--selftest")){int code=selftest();cleanup();return code;}
 SetProcessDPIAware();INITCOMMONCONTROLSEX ic={sizeof(ic),ICC_STANDARD_CLASSES|ICC_BAR_CLASSES};InitCommonControlsEx(&ic);WNDCLASS wc={0};wc.lpfnWndProc=proc;wc.hInstance=inst;wc.lpszClassName=L"NovaCutMain";wc.hCursor=LoadCursor(NULL,IDC_ARROW);wc.hIcon=LoadIcon(inst,MAKEINTRESOURCE(10));RegisterClass(&wc);WNDCLASS vwc={0};vwc.lpfnWndProc=videoProc;vwc.hInstance=inst;vwc.lpszClassName=L"NovaCutVideo";vwc.hCursor=LoadCursor(NULL,IDC_HAND);vwc.hbrBackground=(HBRUSH)GetStockObject(BLACK_BRUSH);RegisterClass(&vwc);win=CreateWindow(wc.lpszClassName,L"NovaCut 2 - Compact Video Editor",WS_OVERLAPPEDWINDOW|WS_CLIPCHILDREN,CW_USEDEFAULT,CW_USEDEFAULT,1280,900,NULL,NULL,inst,NULL);ShowWindow(win,show);UpdateWindow(win);MSG msg;while(GetMessage(&msg,NULL,0,0)>0){if(!IsDialogMessage(win,&msg)){TranslateMessage(&msg);DispatchMessage(&msg);}}DeleteCriticalSection(&processLock);CoUninitialize();return 0;}
