#ifndef NOVACUT_UNPACK_H
#define NOVACUT_UNPACK_H
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "LzmaDec.h"
#include "Bra.h"
static void *ncAlloc(ISzAllocPtr p,size_t n){(void)p;return malloc(n);}
static void ncFree(ISzAllocPtr p,void *v){(void)p;free(v);}
static const ISzAlloc ncAllocator={ncAlloc,ncFree};
static uint32_t ncCRC(const unsigned char *p,size_t n){uint32_t crc=~0u;for(size_t i=0;i<n;i++){crc^=p[i];for(int bit=0;bit<8;bit++)crc=(crc>>1)^(0xedb88320u&-(crc&1));}return ~crc;}
/* Header: length32, crc32, BCJ flag8, LZMA properties5, compressed payload. */
static int ncUnpack(const unsigned char *packed,size_t n,unsigned char **out,size_t *outSize){
 *out=NULL;*outSize=0;if(n<14)return 0;uint32_t expected=0,crc=0;memcpy(&expected,packed,4);memcpy(&crc,packed+4,4);
 if(!expected||expected>250000000||packed[8]>1)return 0;unsigned char *raw=malloc(expected);if(!raw)return 0;
 SizeT size=expected,srcSize=n-14;ELzmaStatus status;
 SRes result=LzmaDecode(raw,&size,packed+14,&srcSize,packed+9,5,LZMA_FINISH_END,&status,&ncAllocator);
 if(result!=SZ_OK||size!=expected||srcSize!=n-14||status!=LZMA_STATUS_FINISHED_WITH_MARK){free(raw);return 0;}
 if(packed[8]){UInt32 state=Z7_BRANCH_CONV_ST_X86_STATE_INIT_VAL;z7_BranchConvSt_X86_Dec(raw,size,0,&state);}
 if(ncCRC(raw,size)!=crc){free(raw);return 0;}*out=raw;*outSize=size;return 1;
}
#endif
