from pathlib import Path
import re
s=Path('build/v3/nova.c').read_text();start=s.index('static void layout(');end=s.index('static void surface(',start);body=s[start:end]
combos={'EFFECT','ROTATE','RES','FPS','SPEED','QUALITY'};movements=re.findall(r'move\(([^;]+)\);',body)
for w,h in [(1280,861),(1120,801),(1600,1000)]:
 env={'w':w,'h':h,'lx':20,'lw':244,'ix':w-294,'iw':274,'cx':284,'cw':w-598};rects={}
 for m in movements:
  args=m.split(',');id=args[0];x,y,width,height=[int(eval(a,{'__builtins__':{}},env)) for a in args[1:]]
  if id in combos:height=30
  assert x>=0 and y>=0 and x+width<=w and y+height<=h,(w,h,id,(x,y,width,height))
  rects[id]=(x,y,x+width,y+height)
 for i,(ida,a) in enumerate(rects.items()):
  for idb,b in list(rects.items())[i+1:]:
   overlap=min(a[2],b[2])-max(a[0],b[0])>0 and min(a[3],b[3])-max(a[1],b[1])>0
   assert not overlap,(w,h,ida,idb,a,b)
 print('PASS control bounds and spacing:',w,h)
