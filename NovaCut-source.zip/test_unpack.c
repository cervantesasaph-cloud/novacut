#include <stdio.h>
#include "unpack.h"
int main(int argc,char **argv){if(argc!=3)return 1;FILE *f=fopen(argv[1],"rb");if(!f)return 2;fseek(f,0,SEEK_END);long n=ftell(f);rewind(f);unsigned char *data=malloc(n);if(fread(data,1,n,f)!=(size_t)n)return 3;fclose(f);unsigned char *out;size_t size;if(!ncUnpack(data,n,&out,&size))return 4;f=fopen(argv[2],"wb");if(!f)return 5;int ok=fwrite(out,1,size,f)==size;fclose(f);free(out);free(data);return ok?0:6;}
