from pathlib import Path
import struct,subprocess,hashlib
r=Path('build/v3');d=(r/'NovaCut.exe').read_bytes();pe=struct.unpack_from('<I',d,0x3c)[0];assert d[:2]==b'MZ' and d[pe:pe+4]==b'PE\0\0';machine,nsec=struct.unpack_from('<HH',d,pe+4);assert machine==0x8664;opt_size=struct.unpack_from('<H',d,pe+20)[0];opt=pe+24;assert struct.unpack_from('<H',d,opt)[0]==0x20b;rrva=struct.unpack_from('<I',d,opt+128)[0];sections=[]
for i in range(nsec):
 off=opt+opt_size+i*40;vs,rva,rs,raw=struct.unpack_from('<IIII',d,off+8);sections.append((rva,max(vs,rs),raw))
def offset(rva):
 for base,size,raw in sections:
  if base<=rva<base+size:return raw+rva-base
 raise ValueError(rva)
root=offset(rrva)
def entries(rel):
 off=root+rel;n1,n2=struct.unpack_from('<HH',d,off+12);return [struct.unpack_from('<II',d,off+16+i*8) for i in range(n1+n2)]
resources={}
for kind,branch in entries(0):
 if kind!=10:continue
 for rid,b2 in entries(branch&0x7fffffff):
  for lang,leaf in entries(b2&0x7fffffff):
   rva,size=struct.unpack_from('<II',d,root+leaf);resources[rid]=d[offset(rva):offset(rva)+size]
assert set(resources)=={1,3}
for rid,name in [(1,'ffmpeg.exe'),(3,'notices.txt')]:
 p=r/('verified-'+name+'.packed');p.write_bytes(resources[rid]);o=r/('verified-'+name)
 subprocess.run([str(r/'test_unpack'),str(p),str(o)],check=True);assert o.read_bytes()==(r/name).read_bytes();print('PASS final resource integrity:',name)
print('EXE bytes',len(d),'MiB',round(len(d)/1048576,3),'previous reduction',round(100*(1-len(d)/3065856),1),'original reduction',round(100*(1-len(d)/78571527),1))
