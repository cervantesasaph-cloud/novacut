import subprocess,pathlib,json,hashlib,numpy as np,tempfile
engine=str(pathlib.Path('build/v2/native-ffmpeg/ffmpeg').resolve());root=pathlib.Path(tempfile.mkdtemp(prefix='feature-check-',dir='build/v2'))
def run(args,stdout=False):
 p=subprocess.run([engine,'-hide_banner','-loglevel','error','-nostdin','-y',*map(str,args)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=40)
 assert p.returncode==0,p.stderr.decode(errors='replace');return p.stdout

def metadata(p):return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(p)]))
a=root/'audio.mp4';b=root/'silent.mp4'
run(['-f','lavfi','-i','testsrc2=size=320x180:rate=30','-f','lavfi','-i','sine=frequency=440:sample_rate=48000','-t',2,'-c:v','libx264','-c:a','aac',a]);run(['-f','lavfi','-i','testsrc2=size=180x320:rate=24','-t',2,'-c:v','libx264',b])
before=[hashlib.sha256(p.read_bytes()).hexdigest() for p in (a,b)]
for speed in (.5,1,2):
 for i,(src,audio,mute) in enumerate(((a,True,False),(a,True,True),(b,False,False))):
  dur=.8/speed;vf=f'transpose=clock,hflip,hue=s=0,setpts=(PTS-STARTPTS)/{speed},scale=854:480:force_original_aspect_ratio=decrease,pad=854:480:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30,format=yuv420p,fade=t=in:st=0:d=0.1,fade=t=out:st={dur-.1}:d=0.1'
  args=['-ss',.2,'-t',.8,'-i',src]
  if not audio:args+=['-f','lavfi','-t',dur,'-i','anullsrc=r=48000:cl=stereo']
  args+=['-map','0:v:0','-map','0:a:0' if audio else '1:a:0','-vf',vf]
  if audio:args+=['-af',f'asetpts=PTS-STARTPTS,atempo={speed},volume={0 if mute else 1.5},afade=t=in:st=0:d=0.1,afade=t=out:st={dur-.1}:d=0.1']
  args+=['-t',dur,'-c:v','libx264','-preset','veryfast','-crf',23,'-c:a','aac','-ar',48000,'-ac',2,'-b:a','160k','-video_track_timescale',15360,root/f'segment{i:03d}.mp4'];run(args)
 (root/'concat.txt').write_text(''.join(f"file 'segment{i:03d}.mp4'\n" for i in range(3)))
 out=root/f'export-{speed}.mp4';run(['-f','concat','-safe',1,'-i',root/'concat.txt','-c','copy','-movflags','+faststart',out]);m=metadata(out)
 assert abs(float(m['format']['duration'])-2.4/speed)<.2;v=next(s for s in m['streams'] if s['codec_type']=='video');assert (v['width'],v['height'])==(854,480);assert any(s['codec_type']=='audio' for s in m['streams']);run(['-i',out,'-f','null','-'])
 # A muted source segment exports audio that is actually silent.
 raw=run(['-i',root/'segment001.mp4','-vn','-c:a','pcm_s16le','-f','wav','pipe:1']) # Inspect decoded PCM with a WAV parser.
 import io,wave
 samples=io.BytesIO(raw)
 with wave.open(samples) as wavefile:
  decoded=np.frombuffer(wavefile.readframes(wavefile.getnframes()),dtype='<i2');assert np.max(np.abs(decoded))<5
 print(f'PASS compact engine export {speed}x: trim, audio/mute/no-audio, filters, rotation/mirror, fades, concat/decode',flush=True)
from PIL import Image
for name,fx,expected in [('gray','hue=s=0',(320,180)),('rotate','transpose=clock',(180,320)),('mirror','hflip',(320,180)),('vivid','eq=brightness=0.04:saturation=1.2:contrast=1.08',(320,180)),('invert','negate',(320,180))]:
 out=root/f'{name}.png';run(['-ss',.5,'-i',a,'-frames:v',1,'-vf',fx,'-c:v','png',out]);im=Image.open(out).convert('RGB');assert im.size==expected
 if name=='gray':
  ar=np.asarray(im);assert np.max(np.abs(ar[:,:,0].astype(int)-ar[:,:,1]))<=1
 print('PASS PNG snapshot',name,flush=True)
for w,h in [(2560,1440),(3840,2160)]:
 out=root/f'{h}p.mp4';run(['-ss',.5,'-i',a,'-frames:v',1,'-vf',f'scale={w}:{h},format=yuv420p','-c:v','libx264','-preset','veryfast',out]);v=next(s for s in metadata(out)['streams'] if s['codec_type']=='video');assert (v['width'],v['height'])==(w,h);print('PASS resolution',w,h,flush=True)
assert before==[hashlib.sha256(p.read_bytes()).hexdigest() for p in (a,b)]
print('PASS original files unchanged')
# All filters needed by C-generated jobs must exist in the reduced engine.
filters=subprocess.check_output([engine,'-hide_banner','-filters'],stderr=subprocess.STDOUT).decode()
for name in ['scale','pad','setsar','fps','format','setpts','asetpts','atempo','volume','apad','anullsrc','transpose','hflip','vflip','hue','eq','negate','fade','afade','null']:
 assert any(line.split()[1:2]==[name] for line in filters.splitlines()),name
print('PASS required compact-engine filters available')
